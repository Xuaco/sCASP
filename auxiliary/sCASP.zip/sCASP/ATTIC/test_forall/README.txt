


To test the c_forall/2 use the following command:

a) to obtain all the solutions (including redundant justifications)

   scasp -n0 --c_forall test05-ok.pl

b) to obtain the first solution (loosing solutions)

   scasp -n0 --once_c_forall test05-ok.pl

c) to check the complete justification tree

   scasp -n0 --once_c_forall --tree --long test05-ok.pl



