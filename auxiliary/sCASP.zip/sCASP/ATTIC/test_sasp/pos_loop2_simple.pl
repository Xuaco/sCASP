%This should fail since the Herbrand Universe only contains one symbol.

q(a).
r(a).

p(X) :- p(Y).
