q(a).
q(b).
q(c).

p(X) :- p(Y).
