p(s(X)).
