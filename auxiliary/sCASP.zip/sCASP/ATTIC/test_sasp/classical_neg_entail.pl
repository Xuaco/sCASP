



p(X) :- not neg_p(X).
neg_p(X) :- not p(X).

-p(1).
