p(X) :- p(X).
