p(X) :- p(X).

q(X):- X=1, not p(X).


