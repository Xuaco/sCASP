?- holdsAt(light_red, 6.999).                            % success  

