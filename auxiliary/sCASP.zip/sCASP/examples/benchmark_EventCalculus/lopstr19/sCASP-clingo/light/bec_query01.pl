?- holdsAt(light_red, 6.9).                            % success  

