?- holdsAt(level(11),T).
