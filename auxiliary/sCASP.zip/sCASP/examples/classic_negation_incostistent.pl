



p(1).
-p(1).



%% no model since the program is inconsistent
?- p(2). 
