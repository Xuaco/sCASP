:- module(html_tail, [load_html_tail/1]).

load_html_tail('\n <div style=\'min-height: 400px\'></div>\n\n</body>\n</html>\n').