name(scasp).
version('0.9.0').
title('Goal directed ASP solver').
keywords([scasp, asp]).
author( 'Joaquin Arias', 'joaquin.arias@urjc.es' ).
author( 'Kyle Marple', '' ).
author( 'Jan Wielemaker', 'jan@swi-prolog.org' ).
home('https://github.com/JanWielemaker/sCASP' ).
download( 'https://github.com/JanWielemaker/sCASP/archive/*.zip' ).
